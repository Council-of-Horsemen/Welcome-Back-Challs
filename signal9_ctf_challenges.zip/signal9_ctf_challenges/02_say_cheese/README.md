##### **Challenge Name:**
Say Cheese

##### **Creator Name:**
Gio

##### **Challenge Type:**
Forensics

##### **Challenge Text:**
Leadership dropped a hype graphic for the new semester. It looks clean, but not everything in a photo is visible to a picture viewer. Something is riding along that shouldn't be, and whatever you carve out of it still needs one more step before it makes sense.

Format: s9(Something_Something)

##### **Potential Points worth:**
100

##### **Files Needed:**
capture.png
