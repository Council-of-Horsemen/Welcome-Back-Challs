##### **Challenge Name:**
Redacted

##### **Creator Name:**
Gio

##### **Challenge Type:**
OSINT

##### **Challenge Text:**
A memo slipped out of the leadership channel. Someone dropped a black box over the one line that mattered and called it secure. Recover what they thought they buried. There's more than one way in, so if the body of the document is stubborn, ask yourself who "signed" it.

Format: s9(Something_Something)

##### **Potential Points worth:**
125

##### **Files Needed:**
internal_memo.pdf
