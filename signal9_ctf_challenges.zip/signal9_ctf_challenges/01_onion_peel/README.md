##### **Challenge Name:**
Onion Peel

##### **Creator Name:**
Gio

##### **Challenge Type:**
Crypto

##### **Challenge Text:**
We intercepted a string on its way out of one of our boxes, but it's wearing two coats of paint. Peel the outer skin off first, then rotate what's underneath back into place.

Format: s9(Something_Something)

##### **Potential Points worth:**
75

##### **Files Needed:**
cipher.txt
