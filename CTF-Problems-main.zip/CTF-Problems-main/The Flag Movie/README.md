##### **Challenge Name:**
The Flag Movie
##### **Creator Name:**
WormBomb
##### **Challenge Type:**
Steganography
##### **Challenge Text:**
I've been working on a script for my upcoming movie. Take a look at it; maybe you'll find a deeper meaning.
Format: s9{EXAMPLE_FLAG}
##### **Potential Points worth:**
75
##### **Files Needed:**
The Flag Movie Script.docx
