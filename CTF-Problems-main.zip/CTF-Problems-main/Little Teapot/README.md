##### **Challenge Name:**
Little Teapot
##### **Creator Name:**
WormBomb
##### **Challenge Type:**
Steganography
##### **Challenge Text:**
We received these strange files from an unrecognized sender. Can you figure out their meaning?
Format: s9{EXAMPLE_FLAG}
##### **Potential Points worth:**
75
##### **Files Needed:**
Inconspicuous.png, Signed Letter.txt, Teapot.png
