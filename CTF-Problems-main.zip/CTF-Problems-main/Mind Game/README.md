##### **Challenge Name:**
Mind Game
##### **Creator Name:**
WormBomb
##### **Challenge Type:**
Forensics/Programming
##### **Challenge Text:**
Who doesn't like a good brain teaser now and then
Format: S9{EXAMPLE_FLAG}
##### **Potential Points worth:**
75
##### **Files Needed:**
Mind Game.bf
