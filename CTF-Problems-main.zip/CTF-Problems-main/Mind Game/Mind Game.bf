As I was going to St Ives
I met a man with seven wives
Each wife had seven sacks
Each sack had seven cats
Each cat had seven kits:
Kits cats sacks and wives
How many were there going to St Ives?

Enter your answer in "+" Here: 

Sample Answer: +++++ (5 People)



+[>++++++++++<-]>+++.
<+++[>----------<-]>++++.
<+++++++[>++++++++++<-]>----.
<+++++[>----------<-]>++++.
----.
+++++.
----------.
<+++[>+++++++++<-]>.
<+++[>---------<-]>--.
++++++++++.
+++.
++++++++.
---------.
<+++++[>++++++++++<-]>---.