##### **Challenge Name:**
Tag-a-long
##### **Creator Name:**
Shadex
##### **Challenge Type:**
Steganography
##### **Challenge Text:**
Hi.

I'll make this easy for you. Here's a zip file with the flag inside.

You're welcome :)
##### **Potential Points worth:**
75 - 100
##### **Files Needed:**
flag_inside.zip
