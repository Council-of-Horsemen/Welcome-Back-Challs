##### **Challenge Name:**
Unbreakable - Part 1
##### **Creator Name:**
Shadex
##### **Challenge Type:**
Misc
##### **Challenge Text:**
A certain company is working to develop the ultimate, most indestructible phone.
We have an insider who has sent us a recording from one of their "performance tests".

Apparently, they've also included some sort of "flag" - whatever that means...
Format: s9(Something_Something)
##### **Potential Points worth:**
50 - 100
##### **Files Needed:**
message.gif
