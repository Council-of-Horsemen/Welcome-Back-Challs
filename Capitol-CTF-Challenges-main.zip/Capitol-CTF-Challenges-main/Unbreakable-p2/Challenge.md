##### **Challenge Name:**
Unbreakable - Part 2
##### **Creator Name:**
Shadex
##### **Challenge Type:**
Misc
##### **Challenge Text:**
So our informant sent us the same recording again... 
I was gonna be so peeved, but then they let us know they've got a new flag to share.

Thing is, I'm pretty sure they botched it or something?...
Oh well. At least they improved the contrast this time around.

Format: s9(Something_Something)
##### **Potential Points worth:**
150 - 200
##### **Files Needed:**
message2.gif
